import { useEffect, useState } from 'react';

interface AvatarProps {
  name: string;
  color: string;
  avatarUrl?: string | null;
  size?: 'sm' | 'md' | 'lg';
  online?: boolean;
  showPresence?: boolean;
}

function getInitials(name: string): string {
  const clean = name.trim();
  if (!clean) return '?';
  const parts = clean.split(/[\s._-]+/).filter(Boolean);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return clean.slice(0, 2).toUpperCase();
}

export function Avatar({
  name,
  color,
  avatarUrl,
  size = 'md',
  online = false,
  showPresence = false,
}: AvatarProps) {
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [avatarUrl]);

  const sizeClasses =
    size === 'sm'
      ? 'h-8 w-8 text-xs'
      : size === 'lg'
        ? 'h-11 w-11 text-sm'
        : 'h-9 w-9 text-xs';

  const safeUrl =
    avatarUrl && (avatarUrl.startsWith('/api/uploads/') || avatarUrl.startsWith('data:image/'))
      ? avatarUrl
      : null;

  return (
    <div className="relative inline-flex shrink-0">
      {safeUrl && !imgFailed ? (
        <img
          src={safeUrl}
          alt={name}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className={`${sizeClasses} rounded-lg object-cover border border-slate-200 select-none`}
        />
      ) : (
        <div
          className={`${sizeClasses} flex items-center justify-center rounded-lg font-semibold tracking-tight text-white select-none`}
          style={{ backgroundColor: color }}
          aria-hidden="true"
        >
          {getInitials(name)}
        </div>
      )}
      {showPresence && (
        <span
          className={`absolute -right-0.5 -bottom-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-white ${
            online ? 'bg-emerald-600' : 'bg-slate-300'
          }`}
          title={online ? 'Online' : 'Offline'}
        />
      )}
    </div>
  );
}
